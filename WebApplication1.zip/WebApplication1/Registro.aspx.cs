﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class Registro : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Lógica de carga de página
        }
    }
}
