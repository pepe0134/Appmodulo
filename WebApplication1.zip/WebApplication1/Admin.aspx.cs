﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class Admin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Código que se ejecuta al cargar la página
        }
    }
}
